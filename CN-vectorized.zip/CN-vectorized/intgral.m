%*** Intergal Term Coefficent***
function BTS = intgral(t,s)
BTS =exp(-pi^2*(t-s));