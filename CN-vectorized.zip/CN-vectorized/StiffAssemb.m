%*** Assembly of stiffness matrix ***
function [A] = StiffAssemb(n4e,nC,area4,d21,d31,nE)
I = reshape(n4e(:,[1 2 3 1 2 3 1 2 3])',9*nE,1);
J = reshape(n4e(:,[1 1 1 2 2 2 3 3 3])',9*nE,1);
a = (sum(d21.*d31,2)./area4)';b = (sum(d31.*d31,2)./area4)';
c = (sum(d21.*d21,2)./area4)';
A = [-2*a+b+c;a-b;a-c;a-b;b;-a;a-c;-a;c];A = sparse(I,J,A(:),nC,nC);
end