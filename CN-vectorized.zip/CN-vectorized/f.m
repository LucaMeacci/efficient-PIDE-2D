%*** Load Vector ***
function laodv = f(x,t)
laodv =(1-2*t).*pi^2.*exp(-pi^2*t).*sin(pi.*x(:,1)).*sin(pi.*x(:,2));