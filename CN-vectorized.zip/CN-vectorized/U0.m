%*** U0 is the initial function ***
function u0 = U0(c4n,time)
x=c4n(:,1);y=c4n(:,2);
u0=exp(-pi^2*time).*sin(pi.*x).*sin(pi.*y);