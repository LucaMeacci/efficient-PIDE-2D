%*** BELRFEMPIDE Solves the PIDE with BE Scheme (Right Rectangular quadrature)*** 
function[U] = BERRFEMPIDE(c4n,n4e,dir,N,dt)
nE = size(n4e,1);nC = size(c4n,1);U = zeros(size(c4n,1),N+1);
%*** Free Nodes ***
FN=setdiff(1:size(c4n,1),unique(dir)); 
%***  Edge vectors w.r.t. first vertex  *** 
c1 = c4n(n4e(:,1),:);d21 = c4n(n4e(:,2),:) - c1;d31 = c4n(n4e(:,3),:) - c1;
%*** Vector of element areas 4*|T| *** 
area4 = 2*(d21(:,1).*d31(:,2)-d21(:,2).*d31(:,1));
%*** Assembly of Stiffness Matrix *** 
A = StiffAssemb(n4e,nC,area4,d21,d31,nE); 
%*** Assembly of Stiffness Matrix *** 
B = MassAssemb(nC, n4e',area4./4); 
%*** Initial Condition *** 
U(:,1) = U0(c4n,0);
for n = 2:N+1
   U(:,n) = solveBERRR(c4n,n4e,dir,dt,FN,A,B,n,U,c1,d21,d31,area4);
end