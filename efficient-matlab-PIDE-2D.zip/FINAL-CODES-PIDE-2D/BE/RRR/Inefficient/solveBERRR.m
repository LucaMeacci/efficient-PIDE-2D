%*** solveCN Solves the PIDE with BE Scheme at each time level*** 
function solBERR = solveBERRR(c4n,n4e,dir,dt,FN,A,B,n,U)
%*** Assembly of Right Hand Side Load Vector *** 
 b = sparse(size(c4n,1),1);
for j = 1:size(n4e,1)
    b(n4e(j,:)) = b(n4e(j,:)) +det([1,1,1; c4n(n4e(j,:),:)'])*dt*(f(sum(c4n(n4e(j,:),:))/3,(n-1)*dt))./6;
end
%*** Contributions from the Intergal Term *** 
Int = 0; 
if n>2
    Int= dt^2*A*U(:,1)*(intgral((n-1)*dt,dt));
    for g=2:n-2
        Int=Int+dt^2*A*U(:,g)*intgral((n-1)*dt,(g)*dt);
    end
end
%*** Computing the P1-FEM BE Approximation ***  
b = b + B * U(:,n-1)+Int;  u = sparse(size(c4n,1),1);
u(unique(dir)) = Ud(c4n(unique(dir),:),(n-1)*dt);   
b = b - (dt * A + B + dt^2*A*intgral( (n-1)*dt,(n-1)*dt )) * u;
u(FN)=(dt *A(FN,FN)+B(FN,FN)+dt^2*A(FN,FN)*intgral((n-1)*dt,(n-1)*dt))\b(FN);
solBERR = u;