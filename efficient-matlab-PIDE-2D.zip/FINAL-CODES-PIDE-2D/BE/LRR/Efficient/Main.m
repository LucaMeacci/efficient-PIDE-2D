 %***  Efficeint Numerical Simulation of PIDE by BE (Left Rectangular Rule) Scheme *** 
%%% Code develpoed by A. Seitenfuss - D. Medeiros - G.M.M. Reddy - L. Meacci%%%
tic;clc;clear all;format short
%Setup parameters
c0 = 1; h = 0.006125; T = 0.1; dt = 0.1; N = round(T/dt); %% Setup dt > time discretization
[c4n1,e,n4e1] = initmesh('lshapeg','hmax',h);
n4e=n4e1';n4e=n4e(:,1:3);dir = e(1:2,:)';c4n = c4n1';c4n = c4n(:,1:2);
U = BELRFEMPIDE(c4n,n4e,dir,N,dt);
trisurf(n4e,c4n(:,1),c4n(:,2),U(:,N+1)','facecolor','interp');hold off
view(10,40); title('Solution of the Problem')
min(full(U(:,N+1)))
max(full(U(:,N+1)))
nE = size(n4e,1)
toc

