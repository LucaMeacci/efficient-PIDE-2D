%*** solveCN Solves the PIDE with CN Scheme at each time level*** 
function solCN = solveCN(c4n,n4e,dir,dt,FN,n,U,A,B)
%*** Assembly of Right Hand Side Load Vector *** 
 b = sparse(size(c4n,1),1);
for j = 1:size(n4e,1)
    b(n4e(j,:)) = b(n4e(j,:)) +det([1,1,1; c4n(n4e(j,:),:)'])*dt*(f(sum(c4n(n4e(j,:),:))/3,(n-1)*dt)+f(sum(c4n(n4e(j,:),:))/3,(n-2)*dt))/12;
end
%*** Contributions from the Intergal Term *** 
Int=1/8*dt^2*A*U(:,1)*(2*intgral((n-1.5)*dt,0)+intgral((n-1.5)*dt,(n-1.5)*dt));
  if n>2
      Int=1/2*dt^2*A*U(:,1)*intgral((n-1.5)*dt,0)+1/8*dt^2*A*U(:,n-1)*(intgral((n-1.5)*dt,(n-1.5)*dt)+6*intgral((n-1.5)*dt,(n-2)*dt)) ;
      for g=2:n-2
          Int=Int+dt^2*A*U(:,g)*intgral((n-1.5)*dt,(g-1)*dt);
      end
  end
%*** Computing the P1-FEM CN Approximation ***  
b = b + (B-dt/2*A) * U(:,n-1)+Int; u = sparse(size(c4n,1),1);
u(unique(dir)) = Ud(c4n(unique(dir),:),(n-1)*dt);
b = b - ((dt/2-dt^2/8*intgral((n-1.5)*dt,(n-1)*dt)) * A + B) * u;
u(FN)=((dt/2-dt^2/8*intgral((n-1.5)*dt,(n-1)*dt))*A(FN,FN)+B(FN,FN))\b(FN);
solCN = u;
 