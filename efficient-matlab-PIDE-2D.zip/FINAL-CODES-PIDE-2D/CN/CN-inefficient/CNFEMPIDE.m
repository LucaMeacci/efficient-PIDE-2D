 %*** CNFEMPIDE Solves the PIDE with CN Scheme (trapezoidal quadrature) *** 
function[U] = CNFEMPIDE(c4n,n4e,dir,N,dt)
U = zeros(size(c4n,1),N+1);
%*** Free Nodes ***
FN=setdiff(1:size(c4n,1),unique(dir)); 
%*** Assembly of Stiffness Matrix *** 
A = StiffAssemb(n4e,c4n);
%*** Assembly of Stiffness Matrix *** 
B = MassAssemb(n4e,c4n); 
%*** Initial Condition *** 
U(:,1) = U0(c4n,0);
for n = 2:N+1
   U(:,n) = solveCN(c4n,n4e,dir,dt,FN,n,U,A,B);
end