%*** Assembly of stiffness matrix ***
function [A] = StiffAssemb(n4e,c4n)
A = sparse(size(c4n,1),size(c4n,1));
for j = 1:size(n4e,1)
   A(n4e(j,:),n4e(j,:)) = A(n4e(j,:),n4e(j,:)) + stima3(c4n(n4e(j,:),:));
end
