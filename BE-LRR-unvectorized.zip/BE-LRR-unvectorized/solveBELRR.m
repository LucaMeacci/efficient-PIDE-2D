%*** solveCN Solves the PIDE with BE Scheme at each time level*** 
function solBELR = solveBELRR(c4n,n4e,dir,dt,FN,A,B,n,U)
%*** Assembly of Right Hand Side Load Vector *** 
 b = sparse(size(c4n,1),1);
for j = 1:size(n4e,1)
    b(n4e(j,:)) = b(n4e(j,:)) +det([1,1,1; c4n(n4e(j,:),:)'])*dt*(f(sum(c4n(n4e(j,:),:))/3,(n-1)*dt))./6;
end
%*** Contributions from the Intergal Term *** 
Int=dt^2*A*U(:,1)*(intgral((n-1)*dt,0));
if n>2
    for g=2:n-1         
        Int=Int+dt^2*A*U(:,g)*(intgral((n-1)*dt,(g-1)*dt));
    end
end
b = b + B * U(:,n-1) + Int;  u = sparse(size(c4n,1),1);
u(unique(dir)) = Ud(c4n(unique(dir),:),(n-1)*dt); b = b - (dt*A + B) * u;
u(FN) = (dt*A(FN,FN) + B(FN,FN))\b(FN); solBELR = u;
