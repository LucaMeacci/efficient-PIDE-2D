%*** U_D is the Data on the Dirichlet boundary *** 
function DirichletBoundaryValue = Ud(x,t)                                                                                                                                                                                                                                                                                                                                                   
DirichletBoundaryValue(find(x(:,1)== -1)) = 0; 
DirichletBoundaryValue(find(x(:,1)== 0)) = 0;
DirichletBoundaryValue(find(x(:,1)== 1)) = 0;
DirichletBoundaryValue(find(x(:,2)== -1)) = 0;
DirichletBoundaryValue(find(x(:,2)== 0)) = 0; 
DirichletBoundaryValue(find(x(:,2) == 1)) = 0; 
