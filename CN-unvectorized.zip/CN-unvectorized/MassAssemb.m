%*** Assembly of Mass matrix ***
function [M]=MassAssemb(n4e,c4n) 
M = sparse(size(c4n,1),size(c4n,1));
for j = 1:size(n4e,1)
   M(n4e(j,:),n4e(j,:)) = M(n4e(j,:),n4e(j,:)) + det([1,1,1;c4n(n4e(j,:),:)'])*[2,1,1;1,2,1;1,1,2]/24;
end