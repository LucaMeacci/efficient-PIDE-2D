%*** Assembly of Mass matrix ***
function [M]=MassAssemb(nC,n4e,area) 
I = n4e([1 2 3 1 2 3 1 2 3],:);
J = n4e([1 1 1 2 2 2 3 3 3],:);
A6=area'./6;A12=area'./12;
Kg = [A6;A12;A12;A12;A6;A12;A12;A12;A6];
M = sparse(I(:),J(:),Kg(:),nC,nC);
end